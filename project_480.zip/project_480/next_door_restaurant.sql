CREATE DATABASE next_door_restaurant;
USE next_door_restaurant;


CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    balance DECIMAL(10, 2) NOT NULL DEFAULT 0
);
ALTER TABLE users
ADD created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE users
ADD role INT NOT NULL DEFAULT 0;

select * from users;


CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    image_url VARCHAR(255)
);


CREATE TABLE invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    total_amount DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);


CREATE TABLE invoice_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT,
    product_id INT,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

INSERT INTO products (name, description, price, image_url) VALUES
('Turkish Toast', 'Turkish toast with our own homemade sauce', 99000, 'product_1.png'),
('Egg Avocado Salad', 'Avocado salad with eggs creates a sweet taste.', 79000, 'product_2.png'),
('Pink Guava Tomato Salad', 'Vegetable salad with pink guava, tomatoes and eggs.', 70000, 'product_3.png'),
('Chicken Hamburgers', 'Hamburger with crispy fried chicken.', 109000, 'product_4.png'),
('Taco', 'Crispy cake filled with vegetables.', 139000, 'product_5.png'),
('Gorgeous Orange Color', 'Salmon with sweet and sour orange sauce', 1490000, 'product_6.png');

INSERT INTO users (username, password, role) 
VALUES ('admin', '$2b$12$t9bYN3T9lr1TKyu.9/W2MOtsD.0XNyLTe5bpChyPd5uQrMMurZnie', 1);

select * from invoices;
select * from products;
select * from users;
select * from invoice_items;
SELECT * FROM invoices WHERE user_id = 18;


CREATE TABLE contact_feedbacks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    feedback VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

select * from contact_feedbacks;


