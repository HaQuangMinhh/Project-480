

function escapeHtml(unsafe) {
    if (typeof unsafe !== 'string') {
        return unsafe; 
    }
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

document.addEventListener('DOMContentLoaded', () => {
    fetch('/account')
        .then(response => response.json())
        .then(data => {
            document.getElementById('username').textContent = escapeHtml(data.username);
        })
        .catch(error => console.error('Error fetching account data:', error));

    // Fetch danh sách sản phẩm
    fetch('/products')
        .then(response => response.json())
        .then(products => {
            const productList = document.getElementById('product-list');
            products.forEach(product => {
                const productItem = document.createElement('div');
                productItem.className = 'product-item';
                productItem.dataset.id = product.id;
                productItem.dataset.name = product.name;
                productItem.dataset.price = product.price;

                const img = document.createElement('img');
                img.src = `assets/${product.image_url}`;
                img.alt = escapeHtml(product.name);

                const title = document.createElement('h3');
                title.textContent = escapeHtml(product.name);

                const description = document.createElement('p');
                description.textContent = escapeHtml(product.description);

                const priceDiv = document.createElement('div');
                priceDiv.className = 'price';
                priceDiv.textContent = `${product.price.toLocaleString()} VNĐ`;

                const button = document.createElement('button');
                button.textContent = 'Select';
                button.addEventListener('click', () => selectItem(button));

                productItem.appendChild(img);
                productItem.appendChild(title);
                productItem.appendChild(description);
                productItem.appendChild(priceDiv);
                productItem.appendChild(button);

                productList.appendChild(productItem);
            });
        })
        .catch(error => console.error('Error fetching products:', error));

    // Add event for button Logout

    document.getElementById('logout-button').addEventListener('click', (event) => {
        event.preventDefault();
        logout();
    });

    // Add event for button Search
    document.getElementById('search-button').addEventListener('click', searchDishes);

    // Add event for button Enter int search 
    document.getElementById('search-input').addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            searchDishes();
        }
    });

    // Add event for button Create Invoice
    document.getElementById('create-invoice-button').addEventListener('click', createInvoice);

    // Print alert if there's message
    const params = new URLSearchParams(window.location.search);
    const message = params.get('message');
    if (message) {
        alert(message);
    }
});

const invoiceData = {
    items: []
};

function selectItem(button) {
    const productItem = button.parentElement;
    const id = productItem.getAttribute('data-id');
    const name = productItem.getAttribute('data-name');
    const price = parseFloat(productItem.getAttribute('data-price'));

    const existingItem = invoiceData.items.find(item => item.id === id);

    if (existingItem) {
        existingItem.quantity += 1;
        existingItem.price = price * existingItem.quantity;
    } else {
        invoiceData.items.push({ id, name: escapeHtml(name), price, quantity: 1 });
    }

    localStorage.setItem('invoiceData', JSON.stringify(invoiceData));
    updateInvoiceDisplay();
}

function updateInvoiceDisplay() {
    const invoiceList = document.getElementById('invoice-list');
    const invoiceTotalAmount = document.getElementById('invoice-total-amount');
    invoiceList.innerHTML = '';

    let total = 0;
    invoiceData.items.forEach((item, index) => {
        const invoiceItem = document.createElement('div');
        invoiceItem.className = 'invoice-item';

        const itemName = document.createElement('span');
        itemName.textContent = `${escapeHtml(item.name)} (x${item.quantity})`;
        const itemPrice = document.createElement('span');
        itemPrice.textContent = `${(item.price).toLocaleString()} VNĐ`;

        const removeButton = document.createElement('button');
        removeButton.textContent = 'Remove';
        removeButton.className = 'remove-item';
        removeButton.addEventListener('click', () => removeItem(index));

        invoiceItem.appendChild(itemName);
        invoiceItem.appendChild(itemPrice);
        invoiceItem.appendChild(removeButton);
        invoiceList.appendChild(invoiceItem);

        total += item.price;
    });

    invoiceTotalAmount.textContent = total.toLocaleString() + ' VNĐ';
}

function removeItem(index) {
    invoiceData.items.splice(index, 1);
    localStorage.setItem('invoiceData', JSON.stringify(invoiceData));
    updateInvoiceDisplay();
}

function createInvoice() {
    const invoice_list = JSON.parse(localStorage.getItem('invoiceData'));

    if (!invoice_list || !Array.isArray(invoice_list.items) || invoice_list.items.length === 0) {
        alert('Invoice data is missing or invalid.');
        return;
    }

    fetch('/create-invoice', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(invoice_list)
    })
        .then(response => {
            if (response.ok) {
                return response.json();
            } else {
                return response.text().then(text => {
                    throw new Error(text);
                });
            }
        })
        .then(data => {
            alert('Invoice created successfully! Invoice ID: ' + escapeHtml(data.invoiceId));
            invoiceData.items = [];
            // localStorage.removeItem('invoiceData'); // DELETE INVOICE DISPLAY IN INOVICE.HTML TOO
            updateInvoiceDisplay();
            // window.location.reload();
        })
        .catch(error => {
            console.error('Error creating invoice:', error);
            alert('An error occurred while creating the invoice: ' + error.message);
        });
}

function searchDishes() {
    const query = document.getElementById('search-input').value.toLowerCase();
    const productList = document.getElementById('product-list');
    const productItems = productList.getElementsByClassName('product-item');

    Array.from(productItems).forEach(item => {
        const name = item.querySelector('h3').textContent.toLowerCase();
        item.style.display = name.includes(query) ? 'block' : 'none';
    });
}

function logout() {
    fetch('/logout')
        .then(() => {
            window.location.href = 'login.html';
        })
        .catch(error => console.error('Error during logout:', error));
}
 
       
      

