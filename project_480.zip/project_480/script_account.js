
        document.addEventListener('DOMContentLoaded', () => {
            fetch('/users')
                .then(response => response.json())
                .then(users => {
                    const userList = document.getElementById('user-list');
                    users.forEach(user => {
                        const userRow = document.createElement('tr');
                        userRow.innerHTML = `
                            <td>${user.id}</td>
                            <td>${user.username}</td>
                            <td>${user.role === 1 ? 'Admin' : 'User'}</td>
                            <td><button class="delete-user-button" data-user-id="${user.id}">Delete</button></td>
                        `;
                        userList.appendChild(userRow);
                    });

                    // Add event listeners for delete buttons
                    document.querySelectorAll('.delete-user-button').forEach(button => {
                        button.addEventListener('click', function() {
                            const userId = this.getAttribute('data-user-id');
                            deleteUser(userId);
                        });
                    });
                })
                .catch(error => console.error('Error fetching users:', error));

            document.getElementById('add-user-button').addEventListener('click', addUser);

            // Add event listener for logout button
            document.getElementById('logout-button').addEventListener('click', function(event) {
                event.preventDefault(); // Prevent the default anchor behavior
                logout();
            });
        });

        function addUser() {
            const username = document.getElementById('new-username').value;
            const password = document.getElementById('new-password').value;
            const role = 0; // Default role is User

            fetch('/add-user', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password, role })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error adding user');
                }
                alert('User added successfully!');
                location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById('error-message').textContent = 'Error adding user. Please try again.';
            });
        }

        function deleteUser(userId) {
            fetch(`/delete-user/${userId}`, {
                method: 'DELETE'
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error deleting user');
                }
                alert('User deleted successfully!');
                location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error deleting user. Please try again.');
            });
        }

        function logout() {
            fetch('/logout', { method: 'POST' })
                .then(() => {
                    window.location.href = 'login.html';
                })
                .catch(error => console.error('Error logging out:', error));
        }
    