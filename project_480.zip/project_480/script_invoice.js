
        document.addEventListener('DOMContentLoaded', () => {
            const invoiceData = JSON.parse(localStorage.getItem('invoiceData'));

            if (invoiceData && invoiceData.items.length > 0) {
                const invoiceList = document.getElementById('invoice-list');
                let totalAmount = 0;

                invoiceData.items.forEach(item => {
                    const invoiceItem = document.createElement('div');
                    invoiceItem.className = 'invoice-item';
                    invoiceItem.innerHTML = `
                        <span>${item.name}</span>
                        <span>${item.price.toLocaleString()} VNĐ</span>
                    `;
                    invoiceList.appendChild(invoiceItem);
                    totalAmount += item.price;
                });

                document.getElementById('invoice-total-amount').textContent = totalAmount.toLocaleString() + ' VNĐ';
            } else {
                document.getElementById('invoice-list').innerHTML = '<p>No items in this invoice.</p>';
            }
        });




        function logout() {
            fetch('/logout')
                .then(() => {
                    window.location.href = 'login.html'; 
                })
                .catch(error => console.error('Error during logout:', error));
        }
  
        const params = new URLSearchParams(window.location.search);
        const message = params.get('message');
        if (message) {
          alert(message);
        }