 document.getElementById('register-btn').addEventListener('click', function() {
            const registerForm = document.getElementById('register-form');
            const loginForm = document.getElementById('login-form');

            
            registerForm.classList.toggle('hidden');
            loginForm.classList.toggle('hidden');

            
            this.textContent = registerForm.classList.contains('hidden') ? 'Register' : 'Back to Login';
        });

        
document.getElementById('login-form').addEventListener('submit', function(e) {
    e.preventDefault(); // Ngăn chặn form gửi đi theo cách thông thường

    
    const formData = new FormData(this);
    const data = Object.fromEntries(formData.entries());

    
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams(data)
    })
    .then(response => response.json()) 
    .then(data => {
        if (data.success) {
            
            localStorage.setItem('userId', data.userId);
            localStorage.setItem('username', data.username);

            
            window.location.href = 'customer1.html';
        } else {
            
            alert('Login failed! Please check your username and password.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while logging in.');
    });
});